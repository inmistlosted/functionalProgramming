import Test.HUnit
import DbActions
import Database.PostgreSQL.Simple
import Data.String

safeHead :: [a] -> Maybe a
safeHead []    = Nothing
safeHead (x:_) = Just x

testSafeHeadForEmptyList :: Test
testSafeHeadForEmptyList =
    TestCase $ assertEqual "Should return Nothing for empty list"
                           Nothing (safeHead ([]::[Int]))

testGetClassesOnFloor :: Test
testGetClassesOnFloor = TestCase (do
  a <- getClassesNumbersOnFloor (2 :: Int)
  assertEqual "Should return list with 2 values (201, 212)" [Only {fromOnly = 201},Only {fromOnly = 212}] a)

main :: IO Counts
main = runTestTT $ TestList [testSafeHeadForEmptyList, testGetClassesOnFloor]
